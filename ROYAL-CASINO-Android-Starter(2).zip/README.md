# ROYAL CASINO — Android starter project

This is the first Android prototype for a virtual-coin-only entertainment app.

## Included
- Black & Gold Compose home screen
- Five game entry cards: Slot, Roulette, Poker, Dice, Lucky Wheel
- Local demo wallet starting at 10,000 RC
- Demo play button uses 100 local virtual coins
- No deposits, cash-outs, purchases, or real-money wagering

## Build an APK
The easiest route without a computer is GitHub Actions:
1. Create a GitHub account and a new repository.
2. Upload the contents of this ZIP to the repository (not the ZIP itself).
3. Open the repository's Actions tab.
4. Run the workflow named "Build Android APK".
5. Download `royal-casino-debug-apk` from the completed workflow's Artifacts section.

This starter is a local prototype only. Admin/Super Admin login, secure server-side wallet,
multiplayer games, and production game logic are not implemented yet. Do not use local
coin balances for a public release; move wallet and admin permissions to a trusted backend.
