package com.royalcasino.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF1D1D1D)
private val Gold = Color(0xFFD6AD55)
private val Cream = Color(0xFFF5E7C4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoyalCasinoApp() }
    }
}

@Composable
fun RoyalCasinoApp() {
    var coins by remember { mutableIntStateOf(10000) }
    var selected by remember { mutableStateOf("Home") }
    var message by remember { mutableStateOf("Welcome! Play with virtual coins only.") }
    val games = listOf("Slot Game", "Roulette", "Poker", "Dice", "Lucky Wheel")

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Black) {
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("ROYAL", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("CASINO", color = Cream, fontSize = 15.sp, letterSpacing = 5.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("VIRTUAL WALLET", color = Gold, fontSize = 10.sp)
                        Text("🪙 %,d RC".format(coins), color = Cream, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(22.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("WELCOME TO ROYAL CASINO", color = Gold, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Premium games • Daily fun • Virtual coins only",
                            color = Cream, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("10,000 RC", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        Text("Demo starting balance — no cash value", color = Cream, fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("CHOOSE YOUR GAME", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)) {
                    items(games) { game ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(gameEmoji(game), fontSize = 32.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(game, color = Cream, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = {
                                    if (coins >= 100) {
                                        coins -= 100
                                        message = "$game demo selected. 100 virtual coins used."
                                    } else message = "Not enough demo coins."
                                }, colors = ButtonDefaults.buttonColors(containerColor = Gold,
                                    contentColor = Black), modifier = Modifier.fillMaxWidth()) {
                                    Text("PLAY • 100 RC")
                                }
                            }
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    modifier = Modifier.fillMaxWidth()) {
                    Text(message, color = Cream, modifier = Modifier.padding(12.dp), fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                Text("DEMO BUILD • NO DEPOSITS • NO CASHOUT • NO REAL-MONEY GAMBLING",
                    color = Gold, fontSize = 9.sp)
            }
        }
    }
}

private fun gameEmoji(name: String) = when (name) {
    "Slot Game" -> "🎰"
    "Roulette" -> "🎡"
    "Poker" -> "🂡"
    "Dice" -> "🎲"
    else -> "🎯"
}
